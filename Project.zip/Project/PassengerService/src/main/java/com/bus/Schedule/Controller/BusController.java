package com.bus.Schedule.Controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bus.Schedule.Entity.Passenger;
import com.bus.Schedule.service.BusService;


@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/admin")
public class BusController {
	private Logger log=LoggerFactory.getLogger(BusController.class);
	@Autowired
	BusService service;

	@GetMapping("/getAllPassengers")
	public ResponseEntity<List<Passenger>> getAllPassengers() {
		List<Passenger> passengers = service.getAllPassengers();
		log.debug("Fetching all passengers:+passengers");
		return ResponseEntity.ok().body(passengers);
	}

	@PostMapping("/addPassengers")
	public ResponseEntity<Passenger> addPassenger(@RequestBody Passenger passenger) {
		Passenger addedPassenger = service.addPassenger(passenger);
		log.debug("In addPassenger with passenger:+ passenger");
		return ResponseEntity.ok().body(addedPassenger);
	}
	@GetMapping("/getPassengerById/{id}")
	public ResponseEntity<Passenger> getPassengerById(@PathVariable Integer id) {
	    Passenger passenger = service.getPassengerById(id);
	    log.debug("In getPassengerById with Id:+id");
	    if (passenger != null) {
	        return ResponseEntity.ok().body(passenger);
	    } else {
	        return ResponseEntity.notFound().build();
	    }
	}
    }

