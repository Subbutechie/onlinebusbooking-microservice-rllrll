package com.bus.Schedule.service;

import java.util.List;

import com.bus.Schedule.Entity.Passenger;



public interface IBusService {
	public List<Passenger> getAllPassengers();

	Passenger addPassenger(Passenger passenger);
	Passenger getPassengerById(Integer id);
}

