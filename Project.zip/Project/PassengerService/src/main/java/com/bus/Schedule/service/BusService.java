package com.bus.Schedule.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.bus.Schedule.Entity.Passenger;

import com.bus.Schedule.Repository.PassengerDao;




@Service
public class BusService implements IBusService{
	
	
	
	
	@Autowired
	PassengerDao passengerDao;
	
	
	
	public List<Passenger> getAllPassengers(){
		return passengerDao.findAll();
	}
	
	

	@Override
	public Passenger addPassenger(Passenger passenger) {
	    return passengerDao.save(passenger);
	}



	public Passenger getPassengerById(Integer id) {
		Optional<Passenger> passenger = passengerDao.findById(id);
        return passenger.orElse(null);
    }
	}






	



	




	
	
