package com.micro.service;

import java.util.List;

import com.micro.entity.BusDetails;

public interface IBusService {
	
	public List<BusDetails> getAllBusDetails();

	public BusDetails addBusDetails(BusDetails details);

	public void deleteBus(Integer busNumber);

	public BusDetails updateBus(BusDetails details);

}
