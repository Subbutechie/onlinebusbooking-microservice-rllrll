package com.micro;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;

import com.micro.dao.BusDetailsDao;

import brave.sampler.Sampler;

@EnableEurekaClient
@SpringBootApplication
public class BusServiceApplication implements CommandLineRunner{
	
	@Autowired
	@Qualifier(value="busDetailsDao")
	private BusDetailsDao busDetailsDao;
	
	public static void main(String[] args) {
		SpringApplication.run(BusServiceApplication.class, args);
	}
	
	@Bean
	public Sampler alwaysSampler() {
		
		return Sampler.ALWAYS_SAMPLE;
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
	}

}
