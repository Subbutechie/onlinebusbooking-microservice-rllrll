package com.micro.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.micro.dao.BusDetailsDao;
import com.micro.entity.BusDetails;
import com.micro.exception.BusDetailsNotFoundException;
import com.micro.exception.NullBusDetailsException;
import com.micro.service.IBusService;
@Service
public class BusService implements IBusService{
	
	@Autowired
	BusDetailsDao busDao;
	
	@Override
	public List<BusDetails> getAllBusDetails() {
		return busDao.findAll();
	}

	@Override
	public BusDetails addBusDetails(BusDetails details) {
		if (details == null) {
			throw new NullBusDetailsException("no data provided");
		}
		Integer busNumber = (int) ((Math.random() * 9000) + 1000);
		details.setBusNumber(busNumber);
		busDao.save(details);
		return details;
	}

	@Override
	public void deleteBus(Integer busNumber) {
		if (busNumber == null)
			throw new NullBusDetailsException("No data recieved..");
		Optional<BusDetails> details = busDao.findById(busNumber);
		if (!details.isPresent()) {
			throw new BusDetailsNotFoundException("Bus Details not found");
		}
		busDao.deleteById(busNumber);
	}

	@Override
	public BusDetails updateBus(BusDetails details) {
		if (details == null)
			throw new NullBusDetailsException("No data recieved..");
		Optional<BusDetails> busDetails = busDao.findById(details.getBusNumber());
		if (!busDetails.isPresent()) {
			throw new BusDetailsNotFoundException("Bus with busNumber: " + details.getBusNumber() + " not exists..");
		}
		busDao.save(details);
		return details;
	}

}
