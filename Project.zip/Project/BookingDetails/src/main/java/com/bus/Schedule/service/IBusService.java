package com.bus.Schedule.service;

import java.util.List;

import com.bus.Schedule.Entity.*;

public interface IBusService {

	public List<BookingDetails> getAllBookingDetails();
	
	public void deleteBooking(Integer bookingId, Integer userId);
	
	public void updateUser(User user);
	
	public List<Passenger> getAllPassengers();

	Passenger addPassenger(Passenger passenger);
	
	Passenger getPassengerById(Integer id);
	
	public List<Passenger> getPassengersByBooking(Integer id);
	
	public Passenger updatePassenger(Passenger passenger);
	
	public void deletePassenger(Integer passengerId);
}