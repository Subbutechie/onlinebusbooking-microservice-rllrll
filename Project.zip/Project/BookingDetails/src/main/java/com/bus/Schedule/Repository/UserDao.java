package com.bus.Schedule.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bus.Schedule.Entity.User;

@Repository
public interface UserDao extends JpaRepository<User, Integer> {

}