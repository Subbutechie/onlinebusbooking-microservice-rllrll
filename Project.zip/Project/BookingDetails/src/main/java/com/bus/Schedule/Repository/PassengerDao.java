package com.bus.Schedule.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bus.Schedule.Entity.Passenger;


public interface PassengerDao extends JpaRepository<Passenger, Integer> {

}
