ackage com.bus.controller;

import java.util.List;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bus.entity.BookingDetails;
import com.bus.entity.Passenger;
import com.bus.proxy.PassengerServiceProxy;
import org.slf4j.Logger;

@RestController
@Scope("request")
public class PassengerClientcontroller {
@Autowired
private PassengerServiceProxy passengerServiceProxy;

public static final Logger log=LoggerFactory.getLogger(PassengerClientcontroller.class);

@GetMapping("/admin/getAllPassengers")
public List<Passenger> getAllPassengers(){
	log.debug("In getAllPassengers Handler method...");
	List<Passenger> passengers = passengerServiceProxy.getAllPassengers();
	log.debug("In getAllPassengers with return value passengers:"+ passengers);
	return passengers;
	}

	@GetMapping("/admin/getAllBookingDetails")
	public List<BookingDetails> getAllBookingDetails(){
		log.debug("In getAllBookingDetails Handler method...");
		List<BookingDetails> list = passengerServiceProxy.getAllBookingDetails();
		log.debug("In getAllBookingDetails with return value list:"+ list);
		return list;
	}
	
	@PostMapping("/admin/addPassengers")
	public Passenger addPassenger(@RequestBody Passenger passenger) {
		Passenger addedPassenger = passengerServiceProxy.addPassenger(passenger);
		log.debug("Added Passenger Details==>"+addedPassenger);
		return addedPassenger;
	}
	
	@PutMapping("/admin/updatePassenger")
	public Passenger updatePassenger(@RequestBody Passenger passenger){
		Passenger p = passengerServiceProxy.updatePassenger(passenger);
		log.debug("Updated Passenger Details==>"+p);
		return p;
	}
	
	@DeleteMapping("/admin/deletePassenger/{passengerId}")
	public void deletePassenger(@PathVariable("passengerId") Integer passengerId) {
		log.debug("Deleted Passenger Details");
		passengerServiceProxy.deletePassenger(passengerId);
	}
}