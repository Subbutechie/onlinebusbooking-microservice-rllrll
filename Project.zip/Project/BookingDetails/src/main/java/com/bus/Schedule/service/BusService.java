package com.bus.Schedule.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.bus.Schedule.Entity.Passenger;

import com.bus.Schedule.Repository.PassengerDao;
import com.bus.Schedule.Entity.BookingDetails;
import com.bus.Schedule.Entity.User;
import com.bus.Schedule.exception.BookingDoesNotFoundException;
import com.bus.Schedule.exception.PassengerNotFoundException;
import com.bus.Schedule.exception.UserDoesnotExistException;
import com.bus.Schedule.Repository.BookingDetailsDao;
import com.bus.Schedule.Repository.UserDao;


@Service
public class BusService implements IBusService{
	
	@Autowired
	UserDao userDao;
	
	@Autowired
	PassengerDao passengerDao;
	
	@Autowired
	BookingDetailsDao bookingDao;
	
	
	@Override
	public List<BookingDetails> getAllBookingDetails() {
		return bookingDao.findAll();
	}
	
	@Override
	public void deleteBooking(Integer bookingId, Integer userId) {
		Optional<User> u = userDao.findById(userId);
		Optional<BookingDetails> bd = bookingDao.findById(bookingId);
		if (!bd.isPresent()) {
			throw new UserDoesnotExistException("booking not found");
		}
		if (!u.isPresent()) {
			throw new UserDoesnotExistException("user id not found");
		}
		User user = u.get();
		List<BookingDetails> bookingList = user.getBookingDetails();
		BookingDetails deleteBooking = null;
		for (BookingDetails b : bookingList) {
			if (b.getBookingId() == bookingId) {
				System.out.println("booking id found");
				deleteBooking = b;
			}
		}
		bookingList.remove(deleteBooking);
		user.setBookingDetails(bookingList);
		bookingDao.deleteById(bookingId);
		updateUser(user);
	}
	
	public List<Passenger> getAllPassengers(){
		return passengerDao.findAll();
	}
	
	@Override
	public Passenger addPassenger(Passenger passenger) {
	    return passengerDao.save(passenger);
	}

	public Passenger getPassengerById(Integer id) {
		Optional<Passenger> passenger = passengerDao.findById(id);
        return passenger.orElse(null);
    }
	
	public List<Passenger> getPassengersByBooking(Integer id){
		if (id == null) throw new BookingDoesNotFoundException("no data provided");
		Optional<BookingDetails> details = bookingDao.findById(id);
		if (!details.isPresent())
			throw new BookingDoesNotFoundException("booking not found");
		return details.get().getPassengers();
	}
	
	@Override
	public Passenger updatePassenger(Passenger passenger) {
		if (passenger == null) {
			throw new PassengerNotFoundException("no data provided");
		}
		Optional<Passenger> oldPassenger = passengerDao.findById(passenger.getPassengerId()); 
		if (!oldPassenger.isPresent()) {
			throw new PassengerNotFoundException("passenger not found");
		}
		passengerDao.save(passenger);
		return passenger;
	}

	@Override
	public void updateUser(User user) {
		
		
	}
	
	@Override
	public void deletePassenger(Integer passengerId) {
		Optional<Passenger> passenger = passengerDao.findById(passengerId);
		if (!passenger.isPresent()) {
			throw new PassengerNotFoundException("passenger Doesnot Exist Exception");
		}
		passengerDao.deleteById(passengerId);
	}
}