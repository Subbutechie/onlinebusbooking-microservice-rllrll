package com.bus.Schedule.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bus.Schedule.Entity.BookingDetails;



@Repository
public interface BookingDetailsDao extends JpaRepository<BookingDetails, Integer> {

}
