package com.example.entity;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "schedule", schema = "hr")
public class schedule {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private Date date;
    private String bus;
    private String location;
    private String departure;
    private Date eta;
    private int availability;
    private int price;

 // Default constructor (no-argument constructor)
    public schedule() {
    }
    
    // Constructors

    public schedule(int id, Date date, String bus, String location, String departure, Date eta, int availability, int price) {
    	this.id= id;
        this.date = date;
        this.bus = bus;
        this.location = location;
        this.departure = departure;
        this.eta = eta;
        this.availability = availability;
        this.price = price;
    }

    // Getters and Setters
    
    public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getBus() {
        return bus;
    }

    public void setBus(String bus) {
        this.bus = bus;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDeparture() {
        return departure;
    }

    public void setDeparture(String departure) {
        this.departure = departure;
    }

    public Date getEta() {
        return eta;
    }

    public void setEta(Date eta) {
        this.eta = eta;
    }

    public int getAvailability() {
        return availability;
    }

    public void setAvailability(int availability) {
        this.availability = availability;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

	@Override
	public String toString() {
		return "schedule [id=" + id + ", date=" + date + ", bus=" + bus + ", location=" + location + ", departure="
				+ departure + ", eta=" + eta + ", availability=" + availability + ", price=" + price + "]";
	}

    // toString method for easy printing

    
    }

