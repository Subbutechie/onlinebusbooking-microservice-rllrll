package com.example.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.entity.schedule;
import com.example.repository.ScheduleRepository;

import java.util.List;
import java.util.Optional;

@Service
@Scope("singleton")
public class ScheduleService {
	@Autowired
    private final ScheduleRepository scheduleRepository;

    @Autowired
    public ScheduleService(ScheduleRepository scheduleRepository) {
        this.scheduleRepository = scheduleRepository;
    }

    public List<schedule> getAllSchedules() {
        return scheduleRepository.findAll();
    }

    public Optional<schedule> getScheduleById(@PathVariable Integer id) {
        return scheduleRepository.findById(id);    }

    public schedule createSchedule(schedule schedule) {
        return scheduleRepository.save(schedule);
    }

    public Optional<schedule> updateSchedule(@PathVariable Integer id, schedule updatedSchedule) {
        Optional<schedule> optionalSchedule = scheduleRepository.findById(id);

        if (optionalSchedule.isPresent()) {
            schedule existingSchedule = optionalSchedule.get();
            
            // Update the fields of existingSchedule with the fields of updatedSchedule
            existingSchedule.setDate(updatedSchedule.getDate());
            existingSchedule.setBus(updatedSchedule.getBus());
            existingSchedule.setLocation(updatedSchedule.getLocation());
            existingSchedule.setDeparture(updatedSchedule.getDeparture());
            existingSchedule.setEta(updatedSchedule.getEta());
            existingSchedule.setAvailability(updatedSchedule.getAvailability());
            existingSchedule.setPrice(updatedSchedule.getPrice());
            
            // Save the updated schedule
            schedule savedSchedule = scheduleRepository.save(existingSchedule);
            return Optional.of(savedSchedule);
        } else {
            return Optional.empty();
        }
    }

    public void deleteSchedule(@PathVariable Integer id) {
        scheduleRepository.deleteById(id);
    }
}
