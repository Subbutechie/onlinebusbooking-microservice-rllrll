package com.example.controller;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.entity.schedule;
import com.example.repository.ScheduleRepository;
import com.example.service.ScheduleService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/admin")
public class ScheduleController {
	
	 private Logger log=LoggerFactory.getLogger(ScheduleController.class);
	
    private final ScheduleRepository scheduleRepository;
    @Autowired
    private ScheduleService service;
    @Autowired
    public ScheduleController(ScheduleRepository scheduleRepository) {
        this.scheduleRepository = scheduleRepository;
    }

    @GetMapping("/getschedule")
    public ResponseEntity<List<schedule>> getAllSchedules() {
    	log.debug("Fetching all schedules:+schedules");
        List<schedule> schedules = service.getAllSchedules();
        return new ResponseEntity<>(schedules, HttpStatus.OK);
    }
    @GetMapping("/getschedule/{id}")
    public ResponseEntity<schedule> getScheduleById(@PathVariable Integer id) {
    	log.debug("In getschedulebyid with Id:+id");
        Optional<schedule> optionalSchedule = service.getScheduleById(id);

        if (optionalSchedule.isPresent()) {
            return new ResponseEntity<>(optionalSchedule.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/addschedule")
    public ResponseEntity<schedule> createSchedule(@RequestBody schedule schedule) {
        schedule savedSchedule = scheduleRepository.save(schedule);
        return new ResponseEntity<>(savedSchedule, HttpStatus.CREATED);
    }

    @PutMapping("/updateschedule/{id}")
    public ResponseEntity<schedule> updateSchedule(@PathVariable Integer id, @RequestBody schedule updatedSchedule) {
        Optional<schedule> schedule = service.updateSchedule(id, updatedSchedule);

        if (updatedSchedule != null) {
            return new ResponseEntity<>(updatedSchedule, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
    
    
    @DeleteMapping("/deleteschedule/{id}")
    public ResponseEntity<Void> deleteSchedule(@PathVariable Integer id) {
        scheduleRepository.deleteById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
