package com.example.service;

import java.util.List;
import java.util.Optional;

import com.example.entity.schedule;

public interface IScheduleService {

    List<schedule> getAllSchedules();

    Optional<schedule> getScheduleById(Integer id);

    schedule createSchedule(schedule schedule);

    Optional<schedule> updateSchedule(Integer id, schedule updatedSchedule);

    void deleteSchedule(Integer id);
}

