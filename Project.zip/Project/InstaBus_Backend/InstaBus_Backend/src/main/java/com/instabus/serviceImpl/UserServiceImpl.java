package com.instabus.serviceImpl;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.instabus.dao.UserDao;

import com.instabus.entity.User;

import com.instabus.exception.NullUserException;

import com.instabus.exception.UserAlreadyExistException;
import com.instabus.exception.UserDoesnotExistException;
import com.instabus.service.UserService;
import com.instabus.utils.UserAuth;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	UserDao userDao;

	

	@Override
	public User addUser(User user) {

		if (user == null)
			throw new NullUserException("No data received");
		Integer userId = (int) ((Math.random() * 900) + 100);
		user.setUserId(userId);
		Optional<User> checkUser = userDao.findById(user.getUserId());
		if (checkUser.isPresent())
			throw new UserAlreadyExistException("user already exists");

		userDao.save(user);
		System.out.println("user Added");
		return user;

	}

	
	@Override
	public User updateUser(User user) {
	    if (user == null)
	        throw new NullUserException("No data received");

	    // Check if the user exists in the database
	    Optional<User> existingUserOptional = userDao.findById(user.getUserId());

	    if (existingUserOptional.isPresent()) {
	        // User exists, so update the user information
	        User existingUser = existingUserOptional.get();
	        existingUser.setUserName(user.getUserName());
	        existingUser.setPassword(user.getPassword());
	        existingUser.setPhone(user.getPhone());
	        existingUser.setEmail(user.getEmail());
	        userDao.save(existingUser);
	        return existingUser; // Return the updated user
	    } else {
	        throw new UserDoesnotExistException("User not found");
	    }
	}


	
	@Override
	public User getUser(Integer userId) {
		if (userId == null)
			throw new NullUserException("No data received");
		Optional<User> user = userDao.findById(userId);
		if (!user.isPresent())
			throw new UserDoesnotExistException("User not found");
		return user.get();
	}

	
	@Override
	public void deleteUser(Integer userId) {
		if (userId == null)
			throw new NullUserException("No data received");
		Optional<User> user = userDao.findById(userId);
		if (!user.isPresent())
			throw new UserDoesnotExistException("User not found");
		userDao.deleteById(userId);
	}

	
	@Override
	public User userLogin(UserAuth auth) {
		if (auth == null) {
			throw new NullUserException("No data received");
		}
		Optional<User> user = userDao.findById(auth.getUserId());
		if (user.isPresent()) {
			if (user.get().getUserId() == auth.getUserId() && user.get().getPassword().equals(auth.getPassword())) {
				return user.get();
			} else {
				throw new UserDoesnotExistException("invalid login id or password");
			}
			
		} else {
			throw new UserDoesnotExistException("User not found");
		}
	}


	@Override
	public void deleteBooking(Integer bookingId, Integer userId) {
		// TODO Auto-generated method stub
		
	}

	
	}


