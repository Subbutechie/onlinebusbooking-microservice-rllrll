package com.instabus.service;

import com.instabus.entity.User;
import com.instabus.utils.UserAuth;

public interface UserService {
	public User addUser(User user);

	public User updateUser(User user);

	public User getUser(Integer userId);

	public void deleteUser(Integer userId);

	public User userLogin(UserAuth auth);

	

	public void deleteBooking(Integer bookingId, Integer userId);

	

}
