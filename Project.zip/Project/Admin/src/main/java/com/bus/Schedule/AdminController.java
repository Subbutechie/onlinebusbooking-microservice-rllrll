package com.bus.Schedule;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.bus.Schedule.Entity.Admin;
import com.instabus.utils.AdminAuth;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping("/admin")
public class AdminController {

    private static final Logger log = LoggerFactory.getLogger(AdminController.class);

    @Autowired
    AdminServiceImpl service;

    @PostMapping("/adminLogin")
    public ResponseEntity<Admin> loginAdmin(@RequestBody AdminAuth auth) {
        log.debug("Calling loginAdmin with Auth: {}", auth);
        Admin admin = service.adminLogin(auth);
        log.debug("Received Admin response: {}", admin);
        return ResponseEntity.ok(admin);
    }

    @GetMapping("/getAdmin/{id}")
    public ResponseEntity<Admin> getAdmin(@PathVariable Integer id) {
        log.debug("Calling getAdmin with ID: {}", id);
        Admin admin = service.getAdmin(id);
        log.debug("Received Admin response: {}", admin);
        return ResponseEntity.ok(admin);
    }

    @DeleteMapping("/deleteAdmin/{id}")
    public ResponseEntity<Void> deleteAdmin(@PathVariable Integer id) {
        log.debug("Calling deleteAdmin with ID: {}", id);
        service.deleteAdmin(id);
        log.debug("Deleted Admin with ID: {}", id);
        return new ResponseEntity<Void>(HttpStatus.OK);
    }

    @PostMapping("/addAdmin")
    public ResponseEntity<Admin> addAdmin(@RequestBody Admin admin) {
        log.debug("Calling addAdmin with Admin: {}", admin);
        Admin addedAdmin = service.addAdmin(admin);
        log.debug("Added Admin: {}", addedAdmin);
        return ResponseEntity.ok(addedAdmin);
    }
}
