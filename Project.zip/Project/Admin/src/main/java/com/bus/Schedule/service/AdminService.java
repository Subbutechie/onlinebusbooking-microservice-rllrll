package com.bus.Schedule.service;

import com.bus.Schedule.Entity.Admin;
import com.instabus.utils.AdminAuth;

public interface AdminService {
	public Admin addAdmin(Admin admin);

	public Admin getAdmin(Integer adminId);

	public void deleteAdmin(Integer adminId);

	public Admin adminLogin(AdminAuth auth);

	

}