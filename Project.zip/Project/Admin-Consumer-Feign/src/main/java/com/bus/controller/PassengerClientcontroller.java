package com.bus.controller;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bus.entity.Passenger;
import com.bus.proxy.PassengerServiceProxy;

@RestController
@Scope("request")
public class PassengerClientcontroller {
@Autowired
private PassengerServiceProxy passengerServiceProxy;
private Logger log=LoggerFactory.getLogger(PassengerClientcontroller.class);

@GetMapping("/admin/getAllPassengers")
public List<Passenger> getAllPassengers(){
	List<Passenger> passengers = passengerServiceProxy.getAllPassengers();
	log.debug("Fetching all passengers:+passengers");
	return passengers;
}

@GetMapping("/admin/getPassengerById/{id}")
public Passenger getPassengerById(@PathVariable Integer id) {
	log.debug("In getPassengerById with Id:+id");
    return passengerServiceProxy.getPassengerById(id);
}
@PostMapping("/admin/addPassengers")
public ResponseEntity<Passenger> addPassenger(@RequestBody Passenger passenger) {
	Passenger addedPassenger = passengerServiceProxy.addPassenger(passenger);
	log.debug("In addPassenger with passenger:+ passenger");
	return ResponseEntity.ok().body(addedPassenger);
}
}

	
