package com.bus.proxy;

import java.util.ArrayList;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;

import com.bus.entity.Location;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient(name="location-service")
public interface LocationServiceProxy {
	
	@Retry(name = "location-service")
	@CircuitBreaker(name = "location-service", fallbackMethod = "addLocationFB")
	@PostMapping(value = "/addLocation" ,produces = {MediaType.APPLICATION_JSON_VALUE})
	public Location addLocation(Location location);
	
	
	@Retry(name = "location-service")
	@CircuitBreaker(name = "location-service", fallbackMethod = "getAllLocationFB")
	@GetMapping(value = "/getLocation", produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<Location> getAllLocations();
	
	
	@Retry(name = "location-service")
	@CircuitBreaker(name = "location-service", fallbackMethod = "updateLocationFB")
	@PutMapping(value = "/updateLocation/{id}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public Location updateLocation(@PathVariable("id") Long id,Location newLocation);
	
	
	@Retry(name = "location-service")
	@CircuitBreaker(name = "location-service", fallbackMethod = "deleteLocationFB")
	@DeleteMapping(value = "/deleteLocation/{id}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public void deleteLocation(@PathVariable("id") Long id);

	
	
	
	public default Location addLocationFB(Throwable cause) {
		System.out.println("Exception raised with message:==>" +cause.getMessage());
		return new Location();
	}
	
	public default List<Location> getAllLocationFB(Throwable cause) {
		System.out.println("Exception raised with message:==>" +cause.getMessage());
		System.out.println("Cannot get the locations");
		return new ArrayList<Location>();
	}
	
	public default Location updateLocationFB(Throwable cause) {
		System.out.println("Exception raised with message:==>" +cause.getMessage());
		return new Location();
	}
	
	/*public default Location deleteLocationFB(Throwable cause) {
		System.out.println("Exception raised with message:==>" +cause.getMessage());
		return null;
	}*/
	public default void deleteLocationFB(Long id, Throwable cause) {
	    System.out.println("Exception raised with message: ==> " + cause.getMessage());
	    return ; // You can return an appropriate fallback response here.
	}

}
