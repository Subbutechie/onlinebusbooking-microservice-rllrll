package com.bus.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bus.proxy.BusServiceProxy;
import com.bus.entity.BusDetails;

@RestController
@Scope("request")
public class BusController {
	
		private static final Logger log = LoggerFactory.getLogger(BusController.class);

	
		@Autowired
		private BusServiceProxy busServiceProxy;
		
		
		
		@GetMapping("/admin/getAllBusDetails")
		public List<BusDetails> getAllBusDetails(){
			List<BusDetails> list = busServiceProxy.getAllBusDetails();
			log.debug("All Buses: "+ list);
			return list;
		}
		
		@PostMapping("/admin/addBusDetails")
		public BusDetails addBus(@RequestBody BusDetails busDetails){
			BusDetails details = busServiceProxy.addBusDetails(busDetails);
			log.debug("Added Bus Details==>"+details);
			return details;
		}
		
		@DeleteMapping("/admin/deleteBusDetails/{busNumber}")
		public void deleteBus(@PathVariable Integer busNumber) {
			busServiceProxy.deleteBus(busNumber);
		}
		
		@PutMapping("/admin/updateBusDetails")
		public BusDetails updateBus(@RequestBody BusDetails busDetails){
			BusDetails details = busServiceProxy.updateBus(busDetails);
			log.debug("Updated Bus Details==>" +details);
			return details;
		}
}
	
	
