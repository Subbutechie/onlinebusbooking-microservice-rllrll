package com.bus.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bus.entity.User;
import com.bus.proxy.UserServiceProxy;
import com.instabus.utils.UserAuth;




@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping("/user")
@Scope("request")
public class UserController {
	
	private static final Logger log = LoggerFactory.getLogger(UserController.class);
	
	@Autowired
    private UserServiceProxy service;

	
	
	/*
	 * @PostMapping("/addUser") public ResponseEntity<User>
	 * addUser(@Valid @RequestBody User user, Errors error) { if (error.hasErrors())
	 * { throw new UserValidationException("Invalid data provided"); }
	 * 
	 * log.debug("In addUser with addeduser:+user"); User addedUser =
	 * service.addUser(user);
	 * 
	 * return ResponseEntity.ok().body(addedUser); }
	 */
	
	
	/*
	 * @PostMapping("/addUser") public User addLocation(@RequestBody User location)
	 * { User newuser = proxy.addUser(User);
	 * log.debug("Added Terminal Details==>"+newuser); return newuser;
	 * 
	 * }
	 * 
	 */
	

	/*
	 * @PostMapping("user/addUser") public User addAdmin(@RequestBody User user) {
	 * log.debug("Calling addUser with User: {}", user); User response =
	 * service.addUser(user); log.debug("Added User: {}", response); return
	 * response; }
	 */
    
    
    @PostMapping("/addUser")
    public ResponseEntity<User> addUser(@RequestBody User user) {
    	User addedUser = service.addUser(user);
    	log.debug("In addUser with user:+ user");
    	return ResponseEntity.ok().body(addedUser);
    }

    
	
	  @PostMapping("/userLogin") public ResponseEntity<User> loginUser(@RequestBody
	  UserAuth auth) { User user = service.userLogin(auth); return
	  ResponseEntity.ok().body(user); }
	 

    
    
    @GetMapping("/getUser/{id}")
    public ResponseEntity<User> getUser(@PathVariable Integer id) {
        User user = service.getUser(id);
        log.debug("In getUser with userId:+userId");
        return ResponseEntity.ok(user);
    }
    
    

   
	
	  @PostMapping("/updateUser/{userId}") 
	  public ResponseEntity<User> updateUser(@PathVariable Integer userId, @RequestBody User user) {
		  service.updateUser(userId, user); 
		  return new ResponseEntity<User>(HttpStatus.OK); }
	 
	  

	  @DeleteMapping("/deleteUser/{userId}") 
	  public ResponseEntity<Void>deleteUser(@PathVariable Integer userId) { 
		  service.deleteUser(userId);
		  return new ResponseEntity<>(HttpStatus.OK);
	  
	  }
	 
}


	
	
