package com.bus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;

import brave.sampler.Sampler;
@EnableFeignClients
@SpringBootApplication
public class AdminFeignApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdminFeignApplication.class, args);
	}
	@Bean
public Sampler sampler() {
		
		return Sampler.ALWAYS_SAMPLE;
	}

}
