package com.bus.proxy;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import com.bus.entity.Admin;
import com.instabus.utils.AdminAuth;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient("admin-service")
public interface AdminServiceProxy {
	@Retry(name = "admin-service")
    @CircuitBreaker(name = "admin-service", fallbackMethod = "getAdminFB")
    @GetMapping("/admin/getAdmin/{id}")
    Admin getAdmin(@PathVariable Integer id);
	
	@Retry(name = "admin-service")
    @CircuitBreaker(name = "admin-service", fallbackMethod = "loginAdminFB")
    @PostMapping("/admin/adminLogin")
    Admin loginAdmin(@RequestBody AdminAuth auth);
	
	@Retry(name = "admin-service")
    @CircuitBreaker(name = "admin-service", fallbackMethod = "deleteAdminFB")
    @DeleteMapping("/admin/deleteAdmin/{id}")
    Optional<Admin> deleteAdmin(@PathVariable Integer id);
	
	@Retry(name = "admin-service")
    @CircuitBreaker(name = "admin-service", fallbackMethod = "addAdminFB")
    @PostMapping("/admin/addAdmin")
    Admin addAdmin(@RequestBody Admin admin);

    default Admin getAdminFB(Throwable cause) {
        System.out.println("Exception raised with message: ==> " + cause.getMessage());
        return new Admin();
    }

    default Admin loginAdminFB(Throwable cause) {
        System.out.println("Exception raised with message: ==> " + cause.getMessage());
        return new Admin();
    }

    default Optional<Admin> deleteAdminFB(Throwable cause) {
        System.out.println("Exception raised with message: ==> " + cause.getMessage());
        return Optional.empty();
    }

    default Admin addAdminFB(Throwable cause) {
        System.out.println("Exception raised with message: ==> " + cause.getMessage());
        return new Admin();
    }
}
