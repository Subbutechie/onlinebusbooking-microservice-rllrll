package com.bus.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bus.entity.Admin;
import com.bus.proxy.AdminServiceProxy;
import com.instabus.utils.AdminAuth;

@RestController
@Scope("request")
public class AdminClientController {

    private static final Logger log = LoggerFactory.getLogger(AdminClientController.class);

    @Autowired
    private AdminServiceProxy adminServiceProxy;

    @GetMapping("/admin/getAdmin/{id}")
    public ResponseEntity<Admin> getAdmin(@PathVariable Integer id) {
        log.debug("Calling getAdmin with ID: {}", id);
        Admin admin = adminServiceProxy.getAdmin(id);
        if (admin != null) {
            log.debug("Received Admin: {}", admin);
            return ResponseEntity.ok().body(admin);
        } else {
            log.debug("Admin not found for ID: {}", id);
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("admin/deleteAdmin/{id}")
    public ResponseEntity<Void> deleteAdmin(@PathVariable Integer id) {
        log.debug("Calling deleteAdmin with ID: {}", id);
        adminServiceProxy.deleteAdmin(id);
        log.debug("Deleted Admin with ID: {}", id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("admin/adminLogin")
    public Admin adminLogin(@RequestBody AdminAuth auth) {
        log.debug("Calling adminLogin with Auth: {}", auth);
        Admin response = adminServiceProxy.loginAdmin(auth);
        log.debug("Received Admin response: {}", response);
        return response;
    }

    @PostMapping("admin/addAdmin")
    public Admin addAdmin(@RequestBody Admin admin) {
        log.debug("Calling addAdmin with Admin: {}", admin);
        Admin response = adminServiceProxy.addAdmin(admin);
        log.debug("Added Admin: {}", response);
        return response;
    }
}
