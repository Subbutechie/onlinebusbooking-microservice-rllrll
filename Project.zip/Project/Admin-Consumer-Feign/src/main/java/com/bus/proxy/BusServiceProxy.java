package com.bus.proxy;

import java.util.ArrayList;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import com.bus.entity.BusDetails;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;



@FeignClient("bus-service")
public interface BusServiceProxy {
	
	@Retry(name = "bus-service")
	@CircuitBreaker(name = "bus-service", fallbackMethod = "getAllBusDetailsFB")
	@GetMapping(value="/admin/getAllBusDetails",produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<BusDetails> getAllBusDetails();
	
	@Retry(name = "bus-service")
	@CircuitBreaker(name = "bus-service", fallbackMethod = "addBusDetailsFB")
	@PostMapping(value="/admin/addBusDetails",produces = {MediaType.APPLICATION_JSON_VALUE})
	public BusDetails addBusDetails(@RequestBody BusDetails details);
	
	@Retry(name = "bus-service")
	@CircuitBreaker(name = "bus-service", fallbackMethod = "deleteBusFB")
	@DeleteMapping(value="/admin/deleteBusDetails/{busNumber}",produces = {MediaType.APPLICATION_JSON_VALUE})
	public void deleteBus(@PathVariable Integer busNumber);
	
	@Retry(name = "bus-service")
	@CircuitBreaker(name = "bus-service", fallbackMethod = "updateBusFB")
	@PostMapping(value="/admin/updateBusDetails",produces = {MediaType.APPLICATION_JSON_VALUE})
	public BusDetails updateBus(@RequestBody BusDetails details);
	
	
	
	public default BusDetails addBusDetailsFB(Throwable cause) {
		System.out.println("Exception raised with message:==>" +cause.getMessage());
		return new BusDetails();
	}
	
	public default List<BusDetails> getAllBusDetailsFB(Throwable cause) {
		System.out.println("Exception raised with message:==>" +cause.getMessage());
		System.out.println("Cannot get the locations");
		return new ArrayList<BusDetails>();
	}
	
	public default BusDetails updateBusFB(Throwable cause) {
		System.out.println("Exception raised with message:==>" +cause.getMessage());
		return new BusDetails();
	}
	
	public default void  deleteBusFB(Throwable cause) {
		System.out.println("Exception raised with message:==>" +cause.getMessage());
		return ;
	}
	public default void deleteLocationFB(Long id, Throwable cause) {
	    System.out.println("Exception raised with message: ==> " + cause.getMessage());
	    return ; // You can return an appropriate fallback response here.
	}
	
}


