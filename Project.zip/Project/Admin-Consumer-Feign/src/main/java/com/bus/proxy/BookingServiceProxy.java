package com.bus.proxy;

import java.util.*;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.http.MediaType;
import com.bus.entity.BookingDetails;
import com.bus.entity.Passenger;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;



@FeignClient("booking-service")
public interface BookingServiceProxy {
	@Retry(name="booking-service")
	@CircuitBreaker(name = "booking-service", fallbackMethod = "fallbackmethodForGetAllPassengers")
	@GetMapping("/admin/getAllPassengers")
	public List<Passenger> getAllPassengers() ;
	
	@Retry(name="booking-service")
	@CircuitBreaker(name = "booking-service", fallbackMethod = "fallbackmethodForGetAllBookingDetails")
	@GetMapping(value = "/admin/getAllBookingDetails")
	public List<BookingDetails> getAllBookingDetails();
	
	@Retry(name="booking-service")
	@CircuitBreaker(name = "booking-service", fallbackMethod = "addPassengerFB")
	@PostMapping("/admin/addPassengers")
	public Passenger addPassenger(Passenger passenger);
	
	@Retry(name="booking-service")
	@CircuitBreaker(name = "booking-service", fallbackMethod = "updatePassengerFB")
	@PutMapping("/admin/updatePassenger")
	public Passenger updatePassenger(Passenger passenger);
	
	@Retry(name="booking-service")
	@CircuitBreaker(name = "booking-service", fallbackMethod = "deletePassengerFB")
	@DeleteMapping("/admin/deletePassenger/{passengerId}")
	public void deletePassenger(@PathVariable("passengerId") Integer passengerId);
	
	// Fallback methods
    public default  List<Passenger> fallbackmethodForGetAllPassengers(Throwable cause) {
        System.out.println("Exception raised with message: ==> " + cause.getMessage());
        return new ArrayList<Passenger>();
    }
    
    public default  List<BookingDetails> fallbackmethodForGetAllBookingDetails(Throwable cause) {
        System.out.println("Exception raised with message: ==> " + cause.getMessage());
        return new ArrayList<BookingDetails>();
    }
    
    public default Passenger addPassengerFB(Throwable cause) {
		System.out.println("Exception raised with message:==>" +cause.getMessage());
		return new Passenger();
	}
    
    public default Passenger updatePassengerFB(Throwable cause) {
		System.out.println("Exception raised with message:==>" +cause.getMessage());
		return new Passenger();
	}
    
    public default Passenger deletePassengerFB(Throwable cause) {
		System.out.println("Exception raised with message:==>" +cause.getMessage());
		return null;
	}
		
	}