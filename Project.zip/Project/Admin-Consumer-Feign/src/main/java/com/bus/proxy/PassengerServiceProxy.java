package com.bus.proxy;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.bus.entity.Passenger;
import java.util.ArrayList;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;



@FeignClient("BusApp-Service")
public interface PassengerServiceProxy {
	@Retry(name = "BusApp-Service")
	@CircuitBreaker(name = "BusApp-Service", fallbackMethod = "fallbackmethodForGetAllPassengers")
	@GetMapping("/admin/getAllPassengers")
	public List<Passenger> getAllPassengers() ;
	@Retry(name ="BusApp-Service")
	@CircuitBreaker(name = "BusApp-Service", fallbackMethod = "fallbackmethodForGetAllPassengersById")
	@GetMapping("/admin/getPassengerById/{id}") // Define the URL of the endpoint to get a passenger by ID
    Passenger getPassengerById(@PathVariable Integer id);
	
	// Fallback methods
    public default  List<Passenger> fallbackmethodForGetAllPassengers(Throwable cause) {
        System.out.println("Exception raised with message: ==> " + cause.getMessage());
        
//        return getAllPassengers();
        return new ArrayList<Passenger>(3);
    }
    public default Passenger fallbackmethodForGetAllPassengersById(Integer id, Throwable cause) {
        System.out.println("Exception raised with message: ==> " + cause.getMessage());
      return new Passenger(); 
    }
    @Retry(name = "BusApp-Service")
    @CircuitBreaker(name = "BusApp-Service", fallbackMethod = "fallbackmethodForAddPassenger")
    @PostMapping("/admin/addPassengers")
    Passenger addPassenger(@RequestBody Passenger passenger);
    public  default Passenger fallbackmethodForAddPassenger(Passenger passenger, Throwable cause) {
        System.out.println("Exception raised while adding passenger with message: ==> " + cause.getMessage());
        return new Passenger();
    }
	
}


