package com.bus.controller;


import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bus.entity.schedule;
import com.bus.proxy.ScheduleServiceProxy;



@RestController
@RequestMapping("/admin")
public class ScheduleClientController {

    @Autowired
    private ScheduleServiceProxy scheduleServiceProxy;

    private Logger log=LoggerFactory.getLogger(ScheduleClientController.class);
    
    @GetMapping("/getschedule")
    public List<schedule> getAllSchedules() {
    	log.debug("Fetching all schedules:+schedules");
        return scheduleServiceProxy.getAllSchedules();
    }
    

    @GetMapping("/getschedule/{id}")
    public schedule findScheduleById(@PathVariable Integer id) {
    	log.debug("In getschedulebyid with Id:+id");
        schedule schedule = scheduleServiceProxy.getScheduleById(id);
		return schedule;
    }

//    @GetMapping("/admin/schedules/{id}")
//    public Optional<schedule> getScheduleById(@PathVariable Integer id) {
//        return scheduleServiceProxy.getScheduleById(id);
//    }

//    @PostMapping("/")
//    public schedule createSchedule(@RequestBody schedule schedule) {
//        return scheduleServiceProxy.createSchedule(schedule);
//    }
	
//	  @PutMapping("/admin/updateschedule/{id}") 
//	  public schedule updateSchedule(@PathVariable Integer id, @RequestBody schedule updatedSchedule){ 
//		  schedule newschedule = scheduleServiceProxy.updateSchedule(id, updatedSchedule); 
//		  return newschedule;
//	}
//	 
//    @DeleteMapping("/admin/deleteschedule/{id}")
//    public void deleteSchedule(@PathVariable Integer id) {
//        scheduleServiceProxy.deleteSchedule(id);
   }

  

