package com.bus.proxy;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.bus.entity.schedule;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient("schedule-service")
public interface ScheduleServiceProxy {
	
	@Retry(name = "schedule-Service")
	@CircuitBreaker(name = "schedule-Service", fallbackMethod = "fallbackmethodForGetschedules")
	
	
	@GetMapping("/admin/getschedule")
	 public List<schedule> getAllSchedules();
	 
	 @CircuitBreaker(name = "schedule-Service", fallbackMethod = "fallbackmethodForGetschedulesbyid")
	 @GetMapping("/admin/getschedule/{id}")
	 schedule getScheduleById(@PathVariable Integer id);
	
	// Fallback methods
	    public default  List<schedule> fallbackmethodForGetschedules(Throwable cause) {
	        System.out.println("Exception raised with message: ==> " + cause.getMessage());
	        
	        return getAllSchedules();
//	        return new ArrayList<schedule>(3);
	    }
	    public default schedule fallbackmethodForGetschedulesbyid(Integer id, Throwable cause) {
	        System.out.println("Exception raised with message: ==> " + cause.getMessage());
	      return new schedule(); 
	    }
		
	}   
	 
//	    public schedule createSchedule(schedule schedule);
	 
//	 @PutMapping("/admin/updateschedule/{id}")
//	   public schedule updateSchedule(@PathVariable Integer id, schedule updatedSchedule);
//	    @DeleteMapping("/admin/deleteschedule/{id}")
//	    public void deleteSchedule(@PathVariable Integer id);

	    


