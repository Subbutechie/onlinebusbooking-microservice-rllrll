package com.bus.entity;

public class Location {
    
    private Long id;
    private String terminal;
    private String state;
    
    
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getTerminal() {
		return terminal;
	}
	public void setTerminal(String terminal) {
		this.terminal = terminal;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	
	public Location() {
		super();
	}
	
	
	@Override
	public String toString() {
		return "Location [id=" + id + ", terminal=" + terminal + ", state=" + state + "]";
	}
	
	
    
    
}