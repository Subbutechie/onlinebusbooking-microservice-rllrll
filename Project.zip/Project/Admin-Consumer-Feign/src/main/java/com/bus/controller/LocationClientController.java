package com.bus.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bus.entity.Location;
import com.bus.proxy.LocationServiceProxy;

@RestController
@Scope("request")
public class LocationClientController {
	
	private static final Logger log = LoggerFactory.getLogger(LocationClientController.class);
	
	@Autowired
	private LocationServiceProxy proxy;
	
	@GetMapping("/getLocations")
	public List<Location> getAllLocations() {
		
		List<Location> locations = proxy.getAllLocations();
		log.debug("All Terminals: "+ locations);
 		return locations;
	}
	
	@PostMapping("/addLocation")
	public Location addLocation(@RequestBody Location location) {
		Location newlocation =  proxy.addLocation(location);
		log.debug("Added Terminal Details==>"+newlocation);
		return newlocation;
		
	}
	
	 	@PutMapping("/updateLocation/{id}")
	    public Location updateLocation(@PathVariable Long id, @RequestBody Location location) {
	        Location updatedLocation = proxy.updateLocation(id, location);
	        log.debug("Updated Terminal Details==>" +updatedLocation);
	        return updatedLocation;
	    }
	
	 	@DeleteMapping("deleteLocation/{id}")
	 	public void deleteLocation(@PathVariable("id") Long id) {
			proxy.deleteLocation(id);
		}
	
}
