package com.bus.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.bus.entity.User;
import com.instabus.utils.UserAuth;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;


	@FeignClient(name = "USER-SERVICE") // Replace with the actual service name
	public interface UserServiceProxy {
		
		@Retry(name = "BUS-SERVICE")
		@CircuitBreaker(name = "BUS-SERVICE", fallbackMethod = "fallbackmethodForGetUser")
		@GetMapping("/user/getUser/{id}") // Define the URL of the endpoint to get a passenger by ID
		User getUser(@PathVariable Integer id);
		 
		 
		 public default User fallbackmethodForGetUser(Integer id, Throwable cause) {
		        System.out.println("Exception raised with message: ==> " + cause.getMessage());
		      return new User(); 
		    }

		   
		    

			@Retry(name = "BUS-SERVICE")
			@CircuitBreaker(name = "BUS-SERVICE", fallbackMethod = "fallbackmethodForAddUser")
			@PostMapping("/user/addUser")
		    public User addUser(User user);

		 
			 
		    public  default User fallbackmethodForAddUser(User user, Throwable cause) {
		        System.out.println("Exception raised while adding passenger with message: ==> " + cause.getMessage());
		        return new User();
		    }
		    
		 
			



	    @PostMapping("/user/userLogin")
	    User userLogin(@RequestBody UserAuth auth);

	    

		@Retry(name = "BUS-SERVICE")
		@CircuitBreaker(name = "BUS-SERVICE", fallbackMethod = "fallbackmethodForUpdateUser")
	    @PostMapping("/user/updateUser/{userId}")
	    public User updateUser(@PathVariable Integer userId, @RequestBody User user);
		
		
		
		public default User fallbackmethodForUpdateUser(Integer userId, User user, Throwable cause) {
		    System.out.println("Exception raised while updating user with ID " + userId + " with message: ==> " + cause.getMessage());
		    return new User(); 
		}


	    @DeleteMapping("/user/deleteUser/{userId}")
		public void deleteUser(@PathVariable Integer userId);
	    
	}   

	


	

