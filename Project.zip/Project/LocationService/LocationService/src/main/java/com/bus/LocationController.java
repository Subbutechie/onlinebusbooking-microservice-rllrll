package com.bus;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bus.entity.Location;


@RestController
@Scope("request")
public class LocationController {
	
	@Autowired
	@Qualifier(value = "locationService")
	private ILocationService service;
	
	 @PostMapping("/addLocation")
	    public ResponseEntity<Location> addLocationDetails(@RequestBody Location location) {
	        Location savedLocation = service.addLocation(location);
	        return new ResponseEntity<>(savedLocation, HttpStatus.CREATED);
	    }
	    
	    @GetMapping("/getLocation")
	    public ResponseEntity<List<Location>> getLocations() {
	        List<Location> locations = service.getAllLocations();
	        return new ResponseEntity<>(locations, HttpStatus.OK);
	    }

	    
	    @PutMapping("/updateLocation/{id}")
	    public ResponseEntity<Location> updateLocation(@PathVariable Long id, @RequestBody Location location) {
	        Location updatedLocation = service.updateLocation(id, location);

	        if (updatedLocation != null) {
	            return new ResponseEntity<>(updatedLocation, HttpStatus.OK);
	        } else {
	            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	        }
	    }

	    @DeleteMapping("/deleteLocation/{id}")
	    public ResponseEntity<Void> deleteLocation(@PathVariable Long id) {
	        service.deleteLocation(id);
	        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	    }
	
	
	

}
