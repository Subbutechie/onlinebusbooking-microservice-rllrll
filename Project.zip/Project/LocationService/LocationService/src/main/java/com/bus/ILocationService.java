package com.bus;

import java.util.List;

import com.bus.entity.Location;

public interface ILocationService {

	public Location addLocation(Location location);
	
	public List<Location> getAllLocations();
	
	public Location updateLocation(Long id,Location newLocation);
	
	public void deleteLocation(Long id);
	
}
