package com.bus.repository;

import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bus.entity.Location;

@Repository
@Scope(value = "singleton")
public interface LocationRepository extends JpaRepository<Location, Long> {
}