package com.bus.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.bus.ILocationService;
import com.bus.entity.Location;
import com.bus.repository.LocationRepository;

@Service(value = "locationService")
@Scope("singleton")
@Transactional
public class LocationService implements ILocationService{
	
	@Autowired
	private LocationRepository locationRepository;
	
	@Override
	public Location addLocation(Location location) {
		return locationRepository.save(location);
	}

	@Override
	public List<Location> getAllLocations() {
		return locationRepository.findAll();
	}

	@Override
	public Location updateLocation(Long id, Location newLocation) {
	    // Check if the location with the given ID exists in the repository
	    Optional<Location> locationOptional = locationRepository.findById(id);
	    
	    if (locationOptional.isPresent()) {
	        Location existingLocation = locationOptional.get();
	        existingLocation.setTerminal(newLocation.getTerminal());
	        existingLocation.setState(newLocation.getState());

	        // Save the updated location
	        Location updatedLocation = locationRepository.save(existingLocation);

	        return updatedLocation;
	    } else {
	        // Location with the given ID not found
	        return null;
	    }
	}


	@Override
	public void deleteLocation(Long id) {

		locationRepository.deleteById(id);;
	}

	
	
}
